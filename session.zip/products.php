<?php
session_start();


$u = $_GET['txtUsr'];
$_SESSION['uname'] = $u;

?>
<a href="thankyou.php">Go to Thanks Page<a/>









