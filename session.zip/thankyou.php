<?php
	session_start();
	$user = $_SESSION['uname'];
	print ("<h2>Thank you $user</h2>");
?>
<a href="login.html">Go back to login page </a>